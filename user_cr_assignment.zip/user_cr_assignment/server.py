from flask import Flask, render_template, redirect, request,session 
# import the class from user.py
from user import User
app = Flask(__name__)


@app.route('/')
def index():
    return redirect('/users')


@app.route('/users')
def display():
    return render_template("read.html", users=User.get_all())

@app.route("/user/new")
def create_user():
    return render_template("create.html")

@app.route('/create/new_user',methods=['POST'])
def create():
        data = {
            "first_name":request.form['first_name'],
            "last_name":request.form['last_name'],
            "email":request.form ['email']
        }
        print(request.form)
        User.save(request.form)
        return redirect('/users')


if __name__ == "__main__":
    app.run(debug=True)
